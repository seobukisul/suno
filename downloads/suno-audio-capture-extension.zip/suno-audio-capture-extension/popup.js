/**
 * Suno Pure Audio Capture - Popup Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Display Current Extension Version Dynamically
  const manifest = chrome.runtime?.getManifest ? chrome.runtime.getManifest() : null;
  const currentVersion = manifest && manifest.version ? `v${manifest.version}` : 'v1.1.0';
  const extVerEl = document.getElementById('ext-version');
  const footerVerEl = document.getElementById('footer-version');
  if (extVerEl) extVerEl.innerText = currentVersion;
  if (footerVerEl) footerVerEl.innerText = currentVersion;

  const statusTag = document.getElementById('status-tag');
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const trackTitle = document.getElementById('track-title');
  const trackArtist = document.getElementById('track-artist');
  const btnGroup = document.getElementById('btn-group');
  const btnStartWav = document.getElementById('btn-start-wav');
  const btnStartMp3 = document.getElementById('btn-start-mp3');
  const recordingBox = document.getElementById('recording-box');
  const recCurrTime = document.getElementById('rec-curr-time');
  const recPercent = document.getElementById('rec-percent');
  const recDurTime = document.getElementById('rec-dur-time');
  const recBarFill = document.getElementById('rec-bar-fill');
  const btnPopupStop = document.getElementById('btn-popup-stop');
  const btnPopupCancel = document.getElementById('btn-popup-cancel');
  const chkSilentMode = document.getElementById('chk-silent-mode');

  function formatSec(sec) {
    if (!sec || isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }

  // Get active tab and fetch status
  function refreshStatus() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) {
        statusText.innerText = 'Suno 탭을 찾을 수 없습니다.';
        return;
      }

      chrome.tabs.sendMessage(tabs[0].id, { action: 'GET_STATUS' }, (resp) => {
        if (chrome.runtime.lastError || !resp || !resp.success) {
          statusText.innerText = 'Suno 웹페이지를 열어주세요.';
          return;
        }

        const meta = resp.meta || {};
        const cap = resp.captureState || {};

        trackTitle.innerText = meta.title || '재생 중인 곡 없음';
        trackArtist.innerText = meta.artist ? `아티스트: ${meta.artist}` : 'Suno 플레이어 대기 중';

        if (cap.isCapturing) {
          statusDot.className = 'status-dot rec';
          statusText.innerText = `녹음 진행 중 (${(cap.format || 'wav').toUpperCase()})`;
          btnGroup.style.display = 'none';
          recordingBox.style.display = 'block';

          recCurrTime.innerText = formatSec(cap.currentSec);
          recPercent.innerText = `${cap.percent || 0}%`;
          recDurTime.innerText = formatSec(cap.duration);
          recBarFill.style.width = `${cap.percent || 0}%`;
        } else {
          statusDot.className = 'status-dot';
          statusText.innerText = meta.title ? '캡처 준비 완료' : '플레이어 대기 중';
          btnGroup.style.display = 'grid';
          recordingBox.style.display = 'none';
        }
      });
    });
  }

  // Start Capture
  function triggerCapture(format) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) return;
      const silent = chkSilentMode.checked;
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'START_CAPTURE',
        format: format,
        silentMode: silent
      }, () => {
        setTimeout(refreshStatus, 300);
      });
    });
  }

  btnStartWav.addEventListener('click', () => triggerCapture('wav'));
  btnStartMp3.addEventListener('click', () => triggerCapture('mp3'));

  btnPopupStop.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) return;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'STOP_CAPTURE' }, () => {
        setTimeout(refreshStatus, 300);
      });
    });
  });

  btnPopupCancel.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) return;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'CANCEL_CAPTURE' }, () => {
        setTimeout(refreshStatus, 300);
      });
    });
  });

  // Initial Poll and Timer Loop
  refreshStatus();
  const pollInterval = setInterval(refreshStatus, 800);
  window.addEventListener('unload', () => clearInterval(pollInterval));
});
