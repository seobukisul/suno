/**
 * Suno Pure Audio Capture - Background Service Worker (Manifest V3)
 * Manages extension lifecycle and Whale / Chrome runtime compatibility
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Suno Audio Capture] Service worker installed & ready.');
});

// Relays messages between popup and active tab
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'FORWARD_TO_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].id) {
        sendResponse({ success: false, error: '활성화된 Suno 탭을 찾을 수 없습니다.' });
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, message.payload, (resp) => {
        sendResponse(resp || { success: false });
      });
    });
    return true; // async
  }
});
