/**
 * Suno Pure Audio Capture - Content Script
 * Orchestrates Web Audio isolation, player bar UI injection, and real-time HUD
 */

(function () {
  'use strict';

  const EXT_VERSION = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest?.()?.version)
    ? `v${chrome.runtime.getManifest().version}`
    : 'v1.9.0';

  let isScriptInjected = false;
  let activeCaptureState = {
    isCapturing: false,
    format: 'wav',
    title: '',
    artist: '',
    duration: 0,
    currentSec: 0,
    percent: 0,
    silentMode: false
  };
  let activeRecBtn = null;

  // 1. Inject lame.min.js and recorder_bridge.js into Page Context
  function injectPageScripts() {
    if (isScriptInjected) return;
    isScriptInjected = true;

    const lameScript = document.createElement('script');
    lameScript.src = chrome.runtime.getURL('lame.min.js');
    lameScript.onload = () => {
      const bridgeScript = document.createElement('script');
      bridgeScript.src = chrome.runtime.getURL('recorder_bridge.js');
      (document.head || document.documentElement).appendChild(bridgeScript);
    };
    (document.head || document.documentElement).appendChild(lameScript);
    console.log('[Suno Capture] Injected page scripts into MAIN context.');
  }

  // 2. Format Seconds to mm:ss
  function formatTime(sec) {
    if (!sec || isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }

  // 3. Extract Currently Playing Song Metadata from Player Bar
  function getPlayerMetadata() {
    let title = 'Suno Music';
    let artist = 'june';
    let clipId = '';

    const info = findBottomPlayerInfo();
    const audioEl = document.querySelector('audio');

    if (info) {
      const { titleEl, imgEl, playerBar } = info;
      if (titleEl) {
        title = (titleEl.innerText || '').trim() || title;
        const href = titleEl.getAttribute?.('href') || '';
        const m = href.match(/\/(?:song|clip)\/([a-zA-Z0-9_-]+)/);
        if (m) clipId = m[1];
      }

      if (!clipId && imgEl && imgEl.src) {
        const m = imgEl.src.match(/image(?:_large)?_([a-zA-Z0-9-]{36})/i);
        if (m) clipId = m[1];
      }

      if (playerBar) {
        const textNodes = Array.from(playerBar.querySelectorAll('a, span, div, p, h4'))
          .filter(el => {
            const t = (el.innerText || '').trim();
            return t.length > 0 && t.length < 50 && !t.includes(':') && !t.includes('WAV') && !t.includes('MP3');
          });

        const artistEl = textNodes.find(el => el !== titleEl && (el.innerText || '').trim().length > 0);
        if (artistEl) {
          artist = (artistEl.innerText || '').trim() || artist;
        }
      }
    }

    if (!clipId && audioEl && audioEl.src) {
      const m = audioEl.src.match(/([a-zA-Z0-9-]{36})\.(?:mp3|m4a|wav)/i);
      if (m) clipId = m[1];
    }

    return { title, artist, clipId };
  }

  // 4. Floating HUD (Head-Up Display) Management
  let hudEl = null;
  let vuBars = [];

  function createOrShowHUD(meta, format, duration, silentMode) {
    if (!hudEl) {
      hudEl = document.createElement('div');
      hudEl.className = 'suno-hud-overlay';
      hudEl.innerHTML = `
        <div class="suno-hud-header">
          <div class="suno-hud-title-wrap">
            <div class="suno-hud-rec-dot"></div>
            <div class="suno-hud-song-title" id="suno-hud-title">곡 제목</div>
            <span class="suno-hud-version" id="suno-hud-ver-tag">${EXT_VERSION}</span>
          </div>
          <div class="suno-hud-badge ${format}" id="suno-hud-badge">${format.toUpperCase()}</div>
        </div>

        <div class="suno-hud-visualizer" id="suno-hud-visualizer">
          <!-- 12 Equalizer VU bars -->
        </div>

        <div class="suno-hud-progress-wrap">
          <div class="suno-hud-time-row">
            <span class="suno-hud-time-active" id="suno-hud-curr-time">0:00</span>
            <span id="suno-hud-percent">0%</span>
            <span id="suno-hud-dur-time">0:00</span>
          </div>
          <div class="suno-hud-progress-bar-bg">
            <div class="suno-hud-progress-bar-fill" id="suno-hud-progress-fill"></div>
          </div>
        </div>

        <div class="suno-hud-actions">
          <button class="suno-hud-action-btn finish" id="suno-hud-btn-finish">
            ⏹️ 여기까지 다운로드
          </button>
          <button class="suno-hud-action-btn cancel" id="suno-hud-btn-cancel">
            ❌ 취소
          </button>
        </div>

        <label class="suno-hud-mute-label">
          <input type="checkbox" id="suno-hud-chk-mute" ${silentMode ? 'checked' : ''}>
          🔇 스피커 소리 끄기 (조용히 백그라운드 캡처)
        </label>
      `;

      document.body.appendChild(hudEl);

      // Create 12 VU bars
      const viz = hudEl.querySelector('#suno-hud-visualizer');
      vuBars = [];
      for (let i = 0; i < 14; i++) {
        const bar = document.createElement('div');
        bar.className = 'suno-vu-bar';
        viz.appendChild(bar);
        vuBars.push(bar);
      }

      // Finish Button
      hudEl.querySelector('#suno-hud-btn-finish').addEventListener('click', () => {
        window.postMessage({ type: 'SUNO_CMD_STOP_CAPTURE' }, '*');
      });

      // Cancel Button
      hudEl.querySelector('#suno-hud-btn-cancel').addEventListener('click', () => {
        window.postMessage({ type: 'SUNO_CMD_CANCEL_CAPTURE' }, '*');
      });

      // Mute Toggle Checkbox
      hudEl.querySelector('#suno-hud-chk-mute').addEventListener('change', (e) => {
        activeCaptureState.silentMode = e.target.checked;
        window.postMessage({
          type: 'SUNO_CMD_SET_MUTE',
          isMuted: e.target.checked
        }, '*');
      });
    }

    hudEl.style.display = 'block';
    hudEl.querySelector('#suno-hud-title').innerText = meta.title || 'Suno Music';
    hudEl.querySelector('#suno-hud-badge').innerText = format.toUpperCase();
    hudEl.querySelector('#suno-hud-badge').className = `suno-hud-badge ${format}`;
    hudEl.querySelector('#suno-hud-dur-time').innerText = formatTime(duration);
    hudEl.querySelector('#suno-hud-curr-time').innerText = '0:00';
    hudEl.querySelector('#suno-hud-percent').innerText = '0%';
    hudEl.querySelector('#suno-hud-progress-fill').style.width = '0%';
  }

  function updateHUDPulse(data) {
    if (!hudEl || hudEl.style.display === 'none') return;

    hudEl.querySelector('#suno-hud-curr-time').innerText = formatTime(data.currentSec);
    hudEl.querySelector('#suno-hud-percent').innerText = `${data.percent}%`;
    hudEl.querySelector('#suno-hud-progress-fill').style.width = `${data.percent}%`;
    if (data.duration && data.duration > 0) {
      hudEl.querySelector('#suno-hud-dur-time').innerText = formatTime(data.duration);
    }

    // Dynamic Organic VU Meter Bar Heights
    const rms = data.rms || 0;
    const baseHeight = Math.min(100, Math.max(10, rms * 300));
    vuBars.forEach((bar, idx) => {
      // Natural wave harmonic variation
      const harmonic = Math.sin((idx / vuBars.length) * Math.PI) * 0.8 + 0.4;
      const jitter = (Math.random() * 0.3) + 0.85;
      const h = Math.min(100, Math.max(8, baseHeight * harmonic * jitter));
      bar.style.height = `${h}%`;
    });
  }

  function hideHUD() {
    if (hudEl) {
      hudEl.style.display = 'none';
    }
  }

  // 5. Toast Notification System
  function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `suno-capture-toast ${type}`;
    toast.innerHTML = `<span>${type === 'success' ? '🎉' : '⚠️'}</span><span>${message}</span>`;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => {
        if (toast.parentElement) toast.parentElement.removeChild(toast);
      }, 400);
    }, 4000);
  }

  // 6. Listen for Events from Page Bridge (recorder_bridge.js)
  window.addEventListener('message', (event) => {
    if (!event.data || !event.data.type) return;

    switch (event.data.type) {
      case 'SUNO_CAPTURE_STARTED':
        activeCaptureState.isCapturing = true;
        activeCaptureState.format = event.data.format;
        activeCaptureState.title = event.data.title;
        activeCaptureState.artist = event.data.artist;
        activeCaptureState.duration = event.data.duration;
        createOrShowHUD(event.data, event.data.format, event.data.duration, event.data.silentMode);
        if (event.data.isWaiting && hudEl) {
          hudEl.querySelector('#suno-hud-curr-time').innerText = '준비 중...';
        }
        break;

      case 'SUNO_CAPTURE_PULSE':
        activeCaptureState.currentSec = event.data.currentSec;
        activeCaptureState.percent = event.data.percent;
        updateHUDPulse(event.data);
        break;

      case 'SUNO_CAPTURE_ENCODING':
        if (hudEl) {
          hudEl.querySelector('#suno-hud-curr-time').innerText = '패키징 중...';
          hudEl.querySelector('#suno-hud-progress-fill').style.width = '100%';
        }
        break;

      case 'SUNO_CAPTURE_COMPLETED':
        activeCaptureState.isCapturing = false;
        if (activeRecBtn) {
          activeRecBtn.classList.remove('active-rec');
          activeRecBtn = null;
        }
        hideHUD();
        showToast(`'${event.data.filename}' 캡처 저장 완료! (${(event.data.size / 1024 / 1024).toFixed(2)} MB)`, 'success');
        break;

      case 'SUNO_CAPTURE_CANCELLED':
        activeCaptureState.isCapturing = false;
        if (activeRecBtn) {
          activeRecBtn.classList.remove('active-rec');
          activeRecBtn = null;
        }
        hideHUD();
        showToast('오디오 캡처가 취소되었습니다.', 'error');
        break;

      case 'SUNO_CAPTURE_ERROR':
        activeCaptureState.isCapturing = false;
        if (activeRecBtn) {
          activeRecBtn.classList.remove('active-rec');
          activeRecBtn = null;
        }
        hideHUD();
        showToast(`오디오 캡처 오류: ${event.data.error}`, 'error');
        break;
    }
  });

  // 7. Locate bottom player artwork, title element, and container
  function findBottomPlayerInfo() {
    // 1. Find the bottom fixed/sticky player container
    let playerBar = document.querySelector('footer, [data-testid*="player" i], [class*="player-bar" i], [class*="bottom-player" i]');
    if (!playerBar || playerBar.getBoundingClientRect().bottom < window.innerHeight - 20) {
      // Find any bar element pinned to the bottom of the viewport
      const bottoms = Array.from(document.querySelectorAll('footer, div, section')).filter(el => {
        const r = el.getBoundingClientRect();
        return r.bottom >= window.innerHeight - 5 &&
               r.top >= window.innerHeight - 150 &&
               r.top <= window.innerHeight - 30 &&
               r.width >= 320 &&
               r.height >= 40;
      });
      if (bottoms.length > 0) {
        playerBar = bottoms.find(el => el.querySelector('audio, input[type="range"], [role="slider"], button[aria-label*="Play" i], button[aria-label*="Pause" i]')) || bottoms[bottoms.length - 1];
      }
    }

    if (!playerBar) return null;

    // 2. Find thumbnail/artwork image inside or associated with playerBar
    let imgEl = playerBar.querySelector('img');
    if (!imgEl) {
      const bottomImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        const r = img.getBoundingClientRect();
        return r.bottom >= window.innerHeight - 130 && r.width >= 24 && r.height >= 24;
      });
      if (bottomImgs.length > 0) imgEl = bottomImgs[bottomImgs.length - 1];
    }

    // 3. Find song title link or text element inside playerBar
    let titleEl = playerBar.querySelector('a[href*="/song/"], a[href*="/clip/"]');

    if (!titleEl && imgEl) {
      // Look for text element right next to imgEl
      let curr = imgEl.parentElement;
      for (let depth = 0; depth < 5; depth++) {
        if (!curr || curr === document.body || curr === playerBar) break;
        const candidateLink = curr.querySelector('a[href*="/song/"], a[href*="/clip/"]');
        if (candidateLink && !candidateLink.closest('#suno-player-title-dl-group')) {
          titleEl = candidateLink;
          break;
        }

        const leafTexts = Array.from(curr.querySelectorAll('a, span, div, p, h4')).filter(el => {
          if (el.querySelector('*')) return false; // leaf only
          const t = (el.innerText || '').trim();
          if (!t || t.length > 60 || /^\d+:\d+$/.test(t) || ['WAV', 'MP3', 'v6', 'V6'].includes(t)) return false;
          const r = el.getBoundingClientRect();
          const imgR = imgEl.getBoundingClientRect();
          return r.left >= imgR.right - 8 && r.left <= imgR.right + 260;
        });

        if (leafTexts.length > 0) {
          leafTexts.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
          titleEl = leafTexts[0];
          break;
        }
        curr = curr.parentElement;
      }
    }

    if (!titleEl) {
      // General search in left portion of playerBar
      const pRect = playerBar.getBoundingClientRect();
      const leftLinks = Array.from(playerBar.querySelectorAll('a')).filter(a => {
        const r = a.getBoundingClientRect();
        return r.left < pRect.left + 350 && (a.innerText || '').trim().length > 0 && !a.closest('#suno-player-title-dl-group');
      });
      if (leftLinks.length > 0) {
        titleEl = leftLinks[0];
      }
    }

    return { playerBar, titleEl, imgEl };
  }

  function findPlayerBar() {
    const info = findBottomPlayerInfo();
    return info ? info.playerBar : null;
  }

  // 8. Cleanup legacy player bar, seek bar, and filter toolbar buttons
  function cleanupUnwantedButtons() {
    // 1. Remove all old/legacy player bar groups anywhere in the document
    document.querySelectorAll(
      '.suno-capture-player-group, .suno-player-bar-buttons, .suno-player-dl-group, [id="suno-player-dl-group"], [id="suno-btn-player-wav"], [id="suno-btn-player-mp3"]'
    ).forEach(el => el.remove());

    // 2. Remove ANY buttons accidentally injected inside or near progress sliders, seek bars, playback controls (Prevent Screenshot 4 duplication bug)
    document.querySelectorAll(
      '[data-testid*="playback" i], [class*="progress" i], [class*="slider" i], [role="slider"], [aria-label*="Seek" i], [class*="controls" i]'
    ).forEach(container => {
      container.querySelectorAll('.suno-player-bar-btn, .suno-player-title-dl-group, .suno-card-btn, button[class*="wav" i], button[class*="mp3" i]').forEach(el => el.remove());
    });

    // 3. Ensure only ONE single .suno-player-title-dl-group exists in the entire document
    const playerTitleGroups = document.querySelectorAll('.suno-player-title-dl-group, #suno-player-title-dl-group');
    if (playerTitleGroups.length > 1) {
      for (let i = 1; i < playerTitleGroups.length; i++) {
        playerTitleGroups[i].remove();
      }
    }

    // 4. Strictly remove any buttons erroneously injected near filters, headers, or search toolbars
    const forbidden = document.querySelectorAll(
      'header, nav, [class*="filter" i], [class*="toolbar" i], [data-testid*="filter" i], [class*="search" i]'
    );
    forbidden.forEach(container => {
      // Never touch player bar at the bottom!
      if (container.getBoundingClientRect().bottom > window.innerHeight - 110) return;
      container.querySelectorAll('.suno-card-capture-wrap, .suno-card-btn').forEach(el => el.remove());
    });
  }

  // Helper to find the true song row container from the song title link
  function getTrueSongRow(link) {
    let el = link.parentElement;
    let candidate = null;
    while (el && el !== document.body) {
      const r = el.getBoundingClientRect();
      if (r.height > 250) break; // Exclude full page containers
      // The song row MUST contain the album art thumbnail (<img>)
      const img = el.querySelector('img');
      if (img && img.src && !img.closest('footer, [class*="player"]')) {
        candidate = el;
        // If it contains buttons or action items, this is definitely the full row
        if (el.querySelectorAll('button').length > 0 || el.querySelector('input[type="checkbox"], [role="checkbox"]')) {
          return el;
        }
      }
      el = el.parentElement;
    }
    return candidate || link.closest('div[role="row"], li') || link.parentElement?.parentElement || link.parentElement;
  }

  // 9. Inject Buttons into Workspace Song Cards (Exactly next to V6 tag, matching user screenshot)
  function injectSongCardButtons() {
    cleanupUnwantedButtons();

    // Query true song links in the workspace song list
    const songLinks = document.querySelectorAll('a[href*="/song/"], a[href*="/clip/"]');

    songLinks.forEach(link => {
      // Strictly exclude player bar at the bottom
      const rect = link.getBoundingClientRect();
      if (rect.bottom >= window.innerHeight - 95) return;
      if (link.closest('footer, [data-testid*="player" i], [class*="player" i]')) return;
      if (link.closest('header, nav, [class*="filter" i], [class*="toolbar" i]')) return;

      const row = getTrueSongRow(link);
      if (!row) return;

      // Avoid duplicate injection
      if (row.querySelector('.suno-card-capture-wrap')) return;

      const href = link.getAttribute('href') || '';
      const m = href.match(/\/(?:song|clip)\/([a-zA-Z0-9_-]+)/);
      let clipId = m ? m[1] : '';

      // Fallback: check thumbnail image src for clipId
      const rowImg = row.querySelector('img');
      if (!clipId && rowImg && rowImg.src) {
        const imgM = rowImg.src.match(/image(?:_large)?_([a-zA-Z0-9-]{36})/i);
        if (imgM) clipId = imgM[1];
      }

      // Find V-tag (e.g. V6) right next to title (Matching Screenshot 1)
      const titleParent = link.parentElement;
      let vTag = null;
      if (titleParent) {
        vTag = Array.from(titleParent.children).find(el => {
          return el !== link && el.innerText && el.innerText.trim().match(/^v\d+/i);
        });
      }
      if (!vTag && link.nextElementSibling && (link.nextElementSibling.innerText || '').trim().match(/^v\d+/i)) {
        vTag = link.nextElementSibling;
      }

      const cardWrap = document.createElement('span');
      cardWrap.className = 'suno-card-capture-wrap';
      cardWrap.style.cssText = 'display: inline-flex !important; align-items: center !important; gap: 6px !important; margin-left: 10px !important; margin-right: 6px !important; vertical-align: middle !important; z-index: 10 !important;';

      // WAV Button (Matching Screenshot 1 with emerald green pill & waveform SVG)
      const wavBtn = document.createElement('button');
      wavBtn.type = 'button';
      wavBtn.className = 'suno-card-btn wav';
      wavBtn.style.cssText = 'display: inline-flex !important; align-items: center !important; justify-content: center !important; gap: 4px !important; padding: 3px 8px !important; border-radius: 6px !important; font-size: 11px !important; font-weight: 800 !important; cursor: pointer !important; user-select: none !important; line-height: 1.2 !important; text-transform: uppercase !important; letter-spacing: 0.5px !important; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35) !important; background: linear-gradient(135deg, rgba(16, 185, 129, 0.22) 0%, rgba(5, 150, 105, 0.35) 100%) !important; color: #34D399 !important; border: 1px solid rgba(16, 185, 129, 0.6) !important;';
      wavBtn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 12px !important; height: 12px !important; flex-shrink: 0 !important;"><path d="M2 10v4"/><path d="M6 6v12"/><path d="M10 3v18"/><path d="M14 8v8"/><path d="M18 5v14"/><path d="M22 10v4"/></svg>
        <span>WAV</span>
      `;
      wavBtn.title = `[${EXT_VERSION}] 이 곡을 16-bit 무손실 WAV로 다운로드`;
      wavBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        triggerCardPlaybackAndCapture(row, link, clipId, 'wav', wavBtn);
      });

      // MP3 Button (Matching Screenshot 1 with electric blue pill & music note SVG)
      const mp3Btn = document.createElement('button');
      mp3Btn.type = 'button';
      mp3Btn.className = 'suno-card-btn mp3';
      mp3Btn.style.cssText = 'display: inline-flex !important; align-items: center !important; justify-content: center !important; gap: 4px !important; padding: 3px 8px !important; border-radius: 6px !important; font-size: 11px !important; font-weight: 800 !important; cursor: pointer !important; user-select: none !important; line-height: 1.2 !important; text-transform: uppercase !important; letter-spacing: 0.5px !important; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35) !important; background: linear-gradient(135deg, rgba(59, 130, 246, 0.22) 0%, rgba(37, 99, 235, 0.35) 100%) !important; color: #60A5FA !important; border: 1px solid rgba(59, 130, 246, 0.6) !important;';
      mp3Btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 12px !important; height: 12px !important; flex-shrink: 0 !important;"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
        <span>MP3</span>
      `;
      mp3Btn.title = `[${EXT_VERSION}] 이 곡을 320k 최고음질 MP3로 다운로드`;
      mp3Btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        triggerCardPlaybackAndCapture(row, link, clipId, 'mp3', mp3Btn);
      });

      cardWrap.appendChild(wavBtn);
      cardWrap.appendChild(mp3Btn);

      // CRITICAL: Insert AFTER vTag if present (Matching Screenshot 1: Title -> V6 -> [WAV] [MP3]), or after link if no vTag
      const insertTarget = vTag || link;
      if (insertTarget.nextSibling) {
        insertTarget.parentNode.insertBefore(cardWrap, insertTarget.nextSibling);
      } else {
        insertTarget.parentNode.appendChild(cardWrap);
      }
    });
  }

  // Dispatch full mouse & pointer event chain to reliably trigger React event handlers
  function dispatchReliableClick(el) {
    if (!el) return;
    try {
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const opts = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: cx,
        clientY: cy,
        pointerId: 1,
        width: 1,
        height: 1
      };
      el.dispatchEvent(new MouseEvent('mouseenter', opts));
      el.dispatchEvent(new MouseEvent('mouseover', opts));
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerdown', opts));
      }
      el.dispatchEvent(new MouseEvent('mousedown', opts));
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerup', opts));
      }
      el.dispatchEvent(new MouseEvent('mouseup', opts));
      el.dispatchEvent(new MouseEvent('click', opts));
      el.click();
    } catch (e) {
      el.click();
    }
  }

  // Click Suno's actual play target inside the song row
  function clickSongRowToPlay(row) {
    if (!row) return;

    // 1. Explicit play button with aria-label or data-testid in row
    const explicitPlayBtn = row.querySelector('button[aria-label*="Play" i], button[aria-label*="재생" i], [data-testid*="play" i]');
    if (explicitPlayBtn && !explicitPlayBtn.classList.contains('suno-card-btn')) {
      dispatchReliableClick(explicitPlayBtn);
      return;
    }

    // 2. The true play button in Suno is attached to the album cover thumbnail!
    const img = row.querySelector('img');
    if (!img) return;

    // Locate the thumbnail container (width/height ~30-140px)
    let thumbContainer = img.parentElement;
    let curr = img.parentElement;
    while (curr && curr !== row) {
      const r = curr.getBoundingClientRect();
      if (r.width >= 28 && r.width <= 140 && r.height >= 28 && r.height <= 140) {
        thumbContainer = curr;
        break;
      }
      curr = curr.parentElement;
    }

    if (thumbContainer) {
      // Simulate hover first to trigger React play overlay if lazy mounted
      thumbContainer.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      thumbContainer.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));

      const playBtn = thumbContainer.querySelector('button');
      if (playBtn && !playBtn.classList.contains('suno-card-btn')) {
        dispatchReliableClick(playBtn);
        return;
      }
      // Click the thumbContainer itself (Suno attaches onClick on thumbnail wrapper)
      dispatchReliableClick(thumbContainer);
    }

    // 3. Click the img element directly
    dispatchReliableClick(img);
  }

  // Helper to trigger card play and synchronize 100% matched capture
  function triggerCardPlaybackAndCapture(row, link, clipId, format, btn) {
    if (activeRecBtn) {
      activeRecBtn.classList.remove('active-rec');
    }
    if (btn) {
      activeRecBtn = btn;
      activeRecBtn.classList.add('active-rec');
    }

    // 1. Song Title
    const rawTitle = link ? link.innerText : row.querySelector('h4, div[class*="title"]')?.innerText;
    const title = (rawTitle || 'Suno Music').replace(/\s*v\d+$/i, '').trim();

    // 2. Artist
    const userLink = document.querySelector('a[href*="/@"]');
    const artist = userLink ? userLink.innerText.replace('@', '').trim() : 'june';

    // 3. Extract expected duration from row thumbnail (e.g. "1:13" overlay badge)
    let expectedDuration = 0;
    const durationNodes = Array.from(row.querySelectorAll('span, div, p')).filter(el => {
      const t = (el.innerText || '').trim();
      return /^\d+:\d{2}$/.test(t) && !t.includes('WAV') && !t.includes('MP3');
    });
    if (durationNodes.length > 0) {
      const dm = durationNodes[0].innerText.trim().match(/^(\d+):(\d{2})$/);
      if (dm) expectedDuration = parseInt(dm[1], 10) * 60 + parseInt(dm[2], 10);
    }
    if (!expectedDuration) {
      const dm = (row.innerText || '').match(/(\d+):(\d{2})/);
      if (dm) expectedDuration = parseInt(dm[1], 10) * 60 + parseInt(dm[2], 10);
    }

    // 4. Strict check: Is THIS exact track (by clipId/stream) ALREADY playing?
    // NEVER rely on title alone, because Suno generation pairs ALWAYS have identical titles!
    const currentMeta = getPlayerMetadata();
    const audioEl = document.querySelector('audio');

    let isAlreadyPlayingThisSong = false;
    if (audioEl && !audioEl.paused) {
      if (clipId && audioEl.src && audioEl.src.includes(clipId)) {
        isAlreadyPlayingThisSong = true;
      } else if (clipId && currentMeta.clipId) {
        isAlreadyPlayingThisSong = (currentMeta.clipId === clipId);
      } else if (!clipId && currentMeta.title && currentMeta.title.trim().toLowerCase() === title.trim().toLowerCase()) {
        // Fallback only if clipId is unavailable: check duration difference
        if (expectedDuration > 0 && audioEl.duration && !isNaN(audioEl.duration)) {
          isAlreadyPlayingThisSong = Math.abs(audioEl.duration - expectedDuration) <= 2.5;
        }
      }
    }

    if (isAlreadyPlayingThisSong) {
      // Already playing! Do NOT click row (clicking it might toggle pause).
      // Rewind to 0:00 and begin capture directly!
      window.postMessage({
        type: 'SUNO_CMD_START_CAPTURE',
        format: format,
        meta: { title, artist, clipId, expectedDuration },
        silentMode: activeCaptureState.silentMode,
        waitForTrackChange: false,
        restartCurrent: true
      }, '*');
      return;
    }

    // 5. Different song or audio stopped: Click the row's play button
    const prevSrc = audioEl ? audioEl.src : '';
    clickSongRowToPlay(row);

    // 6. Tell page bridge to wait for this exact song to load and begin capture from 0:00
    window.postMessage({
      type: 'SUNO_CMD_START_CAPTURE',
      format: format,
      meta: { title, artist, clipId, expectedDuration },
      silentMode: activeCaptureState.silentMode,
      waitForTrackChange: true,
      previousSrc: prevSrc
    }, '*');
  }

  // 10. Inject Dedicated Download Buttons into Bottom-Left Player Bar (Right next to song title)
  function injectPlayerBarButtons() {
    const info = findBottomPlayerInfo();
    if (!info || !info.titleEl) return;

    const { titleEl, playerBar } = info;

    const existing = document.getElementById('suno-player-title-dl-group');
    if (existing && document.body.contains(existing)) {
      if (existing.parentElement && existing.parentElement.classList.contains('suno-player-title-row') && existing.parentElement.contains(titleEl)) {
        return; // Already perfectly positioned right next to song title!
      }
      existing.remove();
    }

    // Create the clean inline button group (Exactly 2 buttons: WAV and MP3)
    const group = document.createElement('span');
    group.id = 'suno-player-title-dl-group';
    group.className = 'suno-player-title-dl-group';
    group.style.cssText = 'display: inline-flex !important; align-items: center !important; gap: 6px !important; margin-left: 10px !important; margin-right: 6px !important; vertical-align: middle !important; white-space: nowrap !important; flex-shrink: 0 !important; z-index: 9999999 !important;';

    // WAV Button (with SVG Waveform Icon)
    const wavBtn = document.createElement('button');
    wavBtn.type = 'button';
    wavBtn.className = 'suno-player-bar-btn wav';
    wavBtn.id = 'suno-bar-btn-wav';
    wavBtn.style.cssText = 'display: inline-flex !important; align-items: center !important; justify-content: center !important; gap: 4px !important; padding: 2px 8px !important; border-radius: 6px !important; font-size: 11px !important; font-weight: 800 !important; cursor: pointer !important; user-select: none !important; line-height: 1.2 !important; letter-spacing: 0.4px !important; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35) !important; text-transform: uppercase !important; background: linear-gradient(135deg, rgba(16, 185, 129, 0.22) 0%, rgba(5, 150, 105, 0.35) 100%) !important; color: #34D399 !important; border: 1px solid rgba(16, 185, 129, 0.6) !important; flex-shrink: 0 !important;';
    wavBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 12px !important; height: 12px !important; flex-shrink: 0 !important;"><path d="M2 10v4"/><path d="M6 6v12"/><path d="M10 3v18"/><path d="M14 8v8"/><path d="M18 5v14"/><path d="M22 10v4"/></svg>
      <span>WAV</span>
    `;
    wavBtn.title = `[${EXT_VERSION}] 현재 재생 중인 곡을 16-bit 무손실 WAV로 다운로드`;
    wavBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const meta = getPlayerMetadata();
      triggerPlayerCapture('wav', meta, wavBtn);
    });

    // MP3 Button (with SVG Music Note Icon)
    const mp3Btn = document.createElement('button');
    mp3Btn.type = 'button';
    mp3Btn.className = 'suno-player-bar-btn mp3';
    mp3Btn.id = 'suno-bar-btn-mp3';
    mp3Btn.style.cssText = 'display: inline-flex !important; align-items: center !important; justify-content: center !important; gap: 4px !important; padding: 2px 8px !important; border-radius: 6px !important; font-size: 11px !important; font-weight: 800 !important; cursor: pointer !important; user-select: none !important; line-height: 1.2 !important; letter-spacing: 0.4px !important; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.35) !important; text-transform: uppercase !important; background: linear-gradient(135deg, rgba(59, 130, 246, 0.22) 0%, rgba(37, 99, 235, 0.35) 100%) !important; color: #60A5FA !important; border: 1px solid rgba(59, 130, 246, 0.6) !important; flex-shrink: 0 !important;';
    mp3Btn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width: 12px !important; height: 12px !important; flex-shrink: 0 !important;"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
      <span>MP3</span>
    `;
    mp3Btn.title = `[${EXT_VERSION}] 현재 재생 중인 곡을 320k 최고음질 MP3로 다운로드`;
    mp3Btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const meta = getPlayerMetadata();
      triggerPlayerCapture('mp3', meta, mp3Btn);
    });

    group.appendChild(wavBtn);
    group.appendChild(mp3Btn);

    // Ensure titleEl and group are contained in a dedicated horizontal flex row (.suno-player-title-row)
    let titleRow = titleEl.closest('.suno-player-title-row');
    if (!titleRow) {
      titleRow = document.createElement('div');
      titleRow.className = 'suno-player-title-row';
      titleRow.style.cssText = 'display: inline-flex !important; align-items: center !important; flex-direction: row !important; flex-wrap: nowrap !important; gap: 8px !important; max-width: none !important; overflow: visible !important; vertical-align: middle !important;';

      if (titleEl.parentNode) {
        titleEl.parentNode.insertBefore(titleRow, titleEl);
        titleRow.appendChild(titleEl);
      }
    }

    // Append our 2 buttons right next to titleEl inside titleRow
    titleRow.appendChild(group);
  }

  function triggerPlayerCapture(format, meta, btn) {
    if (activeRecBtn) {
      activeRecBtn.classList.remove('active-rec');
    }
    if (btn) {
      activeRecBtn = btn;
      activeRecBtn.classList.add('active-rec');
    }
    window.postMessage({
      type: 'SUNO_CMD_START_CAPTURE',
      format: format,
      meta: meta,
      silentMode: activeCaptureState.silentMode,
      waitForTrackChange: false,
      restartCurrent: true
    }, '*');
  }

  // 10. Popup Message Responder
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'GET_STATUS') {
      const meta = getPlayerMetadata();
      sendResponse({
        success: true,
        meta: meta,
        captureState: activeCaptureState
      });
      return true;
    }

    if (message.action === 'START_CAPTURE') {
      const meta = getPlayerMetadata();
      window.postMessage({
        type: 'SUNO_CMD_START_CAPTURE',
        format: message.format || 'wav',
        meta: meta,
        silentMode: !!message.silentMode
      }, '*');
      sendResponse({ success: true });
      return true;
    }

    if (message.action === 'STOP_CAPTURE') {
      window.postMessage({ type: 'SUNO_CMD_STOP_CAPTURE' }, '*');
      sendResponse({ success: true });
      return true;
    }

    if (message.action === 'CANCEL_CAPTURE') {
      window.postMessage({ type: 'SUNO_CMD_CANCEL_CAPTURE' }, '*');
      sendResponse({ success: true });
      return true;
    }
  });

  // 10. Initialization & Periodic UI Check
  injectPageScripts();
  cleanupUnwantedButtons();

  setInterval(() => {
    cleanupUnwantedButtons();
    injectSongCardButtons();
    injectPlayerBarButtons();
  }, 800);

  console.log(`[Suno Audio Capture ${EXT_VERSION}] Content script active and monitoring.`);
})();
