/**
 * Suno Pure Audio Capture - Page Bridge (Runs in Page Context)
 * Direct access to Suno HTMLMediaElement and Web Audio API graph.
 * 100% mathematically isolated from external software, OS, and other tab sounds.
 */

(function () {
  'use strict';

  if (window.__sunoCaptureBridgeLoaded) return;
  window.__sunoCaptureBridgeLoaded = true;

  let audioCtx = null;
  let sourceNode = null;
  let processorNode = null;
  let monitorGain = null;
  let silentGain = null;
  let isCapturing = false;
  let captureFormat = 'wav'; // 'wav' | 'mp3'
  let recordedChunksL = [];
  let recordedChunksR = [];
  let totalRecordedSamples = 0;
  let captureTargetDuration = 0;
  let currentSongMeta = { title: 'Suno Music', artist: 'june', clipId: '' };
  let activeAudioEl = null;

  // Safe Filename sanitizer
  function sanitizeFilename(name) {
    return (name || 'suno_audio')
      .replace(/[/\\?%*:|"<>]/g, '_')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Pure JS 16-bit PCM Linear WAV Encoder
  function encodeAudioBufferToWav(audioBuffer) {
    const numChannels = audioBuffer.numberOfChannels;
    const sampleRate = audioBuffer.sampleRate;
    const length = audioBuffer.length;
    const bytesPerSample = 2; // 16-bit
    const blockAlign = numChannels * bytesPerSample;
    const dataByteCount = length * blockAlign;
    const totalByteCount = 44 + dataByteCount;

    const buffer = new ArrayBuffer(totalByteCount);
    const view = new DataView(buffer);

    function writeString(offset, str) {
      for (let i = 0; i < str.length; i++) {
        view.setUint8(offset + i, str.charCodeAt(i));
      }
    }

    // RIFF Chunk
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + dataByteCount, true);
    writeString(8, 'WAVE');

    // fmt Chunk
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
    view.setUint16(20, 1, true);  // AudioFormat (1 = PCM)
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true); // ByteRate
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, 16, true); // BitsPerSample

    // data Chunk
    writeString(36, 'data');
    view.setUint32(40, dataByteCount, true);

    const channels = [];
    for (let c = 0; c < numChannels; c++) {
      channels.push(audioBuffer.getChannelData(c));
    }

    let offset = 44;
    for (let i = 0; i < length; i++) {
      for (let c = 0; c < numChannels; c++) {
        let s = channels[c][i];
        s = Math.max(-1, Math.min(1, s));
        const int16 = s < 0 ? s * 0x8000 : s * 0x7FFF;
        view.setInt16(offset, int16, true);
        offset += 2;
      }
    }

    return new Blob([buffer], { type: 'audio/wav' });
  }

  // Pure JS High-Definition MP3 Encoder (320kbps Studio Grade + 1152-sample padding + True-Peak Headroom)
  async function encodeAudioBufferToMp3(audioBuffer, kbps = 320) {
    const lame = window.lamejs || globalThis.lamejs;
    if (!lame || !lame.Mp3Encoder) {
      throw new Error('MP3 인코더(lamejs)를 로드할 수 없습니다.');
    }

    // Standardize to 44.1kHz if needed via OfflineAudioContext for 100% universal player compatibility
    let sourceBuffer = audioBuffer;
    if (audioBuffer.sampleRate !== 44100 && typeof OfflineAudioContext !== 'undefined') {
      try {
        const targetRate = 44100;
        const targetLength = Math.round(audioBuffer.duration * targetRate);
        const offlineCtx = new OfflineAudioContext(audioBuffer.numberOfChannels, targetLength, targetRate);
        const srcNode = offlineCtx.createBufferSource();
        srcNode.buffer = audioBuffer;
        srcNode.connect(offlineCtx.destination);
        srcNode.start(0);
        sourceBuffer = await offlineCtx.startRendering();
      } catch (e) {
        console.warn('[MP3 Encoder] Offline resampling fallback:', e);
        sourceBuffer = audioBuffer;
      }
    }

    const channels = sourceBuffer.numberOfChannels;
    const sampleRate = sourceBuffer.sampleRate;
    const encoder = new lame.Mp3Encoder(channels, sampleRate, kbps);

    const left = sourceBuffer.getChannelData(0);
    const right = channels > 1 ? sourceBuffer.getChannelData(1) : left;

    const sampleBlockSize = 1152;
    const rawLen = left.length;
    // Align total samples to exact integer multiple of 1152 to eliminate partial frame dropouts & clicks
    const paddedLen = Math.ceil(rawLen / sampleBlockSize) * sampleBlockSize;

    const leftInt16 = new Int16Array(paddedLen);
    const rightInt16 = new Int16Array(paddedLen);

    // Apply 0.96 (-0.35 dB) headroom margin to completely prevent True-Peak inter-sample clipping & distortion
    const headroom = 0.96;
    for (let i = 0; i < rawLen; i++) {
      let sL = Math.max(-1, Math.min(1, left[i] * headroom));
      leftInt16[i] = sL < 0 ? sL * 0x8000 : sL * 0x7FFF;
      if (channels > 1) {
        let sR = Math.max(-1, Math.min(1, right[i] * headroom));
        rightInt16[i] = sR < 0 ? sR * 0x8000 : sR * 0x7FFF;
      }
    }

    const mp3Chunks = [];
    let totalBytes = 0;

    for (let i = 0; i < paddedLen; i += sampleBlockSize) {
      const leftChunk = leftInt16.subarray(i, i + sampleBlockSize);
      const rightChunk = channels > 1 ? rightInt16.subarray(i, i + sampleBlockSize) : undefined;
      const mp3buf = channels === 1 ? encoder.encodeBuffer(leftChunk) : encoder.encodeBuffer(leftChunk, rightChunk);
      if (mp3buf.length > 0) {
        const u8 = new Uint8Array(mp3buf.buffer, mp3buf.byteOffset, mp3buf.byteLength);
        mp3Chunks.push(u8);
        totalBytes += u8.byteLength;
      }
    }

    const flushBuf = encoder.flush();
    if (flushBuf.length > 0) {
      const u8 = new Uint8Array(flushBuf.buffer, flushBuf.byteOffset, flushBuf.byteLength);
      mp3Chunks.push(u8);
      totalBytes += u8.byteLength;
    }

    // Merge all chunks into a single, contiguous Uint8Array (monolithic MP3 byte stream)
    const monolithicMp3 = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of mp3Chunks) {
      monolithicMp3.set(chunk, offset);
      offset += chunk.byteLength;
    }

    return new Blob([monolithicMp3], { type: 'audio/mp3' });
  }

  // Direct Browser File Trigger
  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = sanitizeFilename(filename);
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 15000);
  }

  // Find Suno Audio Element
  function findAudioElement() {
    const audioTags = Array.from(document.querySelectorAll('audio'));
    if (!audioTags.length) return null;
    // Prefer audio element that is currently playing or has a src
    const playing = audioTags.find(a => !a.paused && a.currentTime > 0);
    if (playing) return playing;
    const withSrc = audioTags.find(a => a.src && a.src.length > 0);
    if (withSrc) return withSrc;
    return audioTags[0];
  }

  // Initialize or Attach Web Audio Graph
  function ensureAudioGraph(audioEl) {
    if (!audioCtx) {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioCtxClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    if (activeAudioEl !== audioEl) {
      activeAudioEl = audioEl;
    }

    if (!audioEl.__sunoSourceNode) {
      audioEl.__sunoSourceNode = audioCtx.createMediaElementSource(audioEl);
    }
    sourceNode = audioEl.__sunoSourceNode;

    // Monitor Gain (controls user speaker volume without affecting capture)
    if (!audioEl.__sunoMonitorGain) {
      audioEl.__sunoMonitorGain = audioCtx.createGain();
      audioEl.__sunoMonitorGain.gain.value = 1.0; // Audible by default
      sourceNode.connect(audioEl.__sunoMonitorGain);
      audioEl.__sunoMonitorGain.connect(audioCtx.destination);
    }
    monitorGain = audioEl.__sunoMonitorGain;

    // Processor Node for isolated PCM capture
    if (!processorNode) {
      const bufferSize = 4096;
      processorNode = audioCtx.createScriptProcessor(bufferSize, 2, 2);

      // Silent dummy gain to keep processorNode ticking in Chrome
      silentGain = audioCtx.createGain();
      silentGain.gain.value = 0;
      processorNode.connect(silentGain);
      silentGain.connect(audioCtx.destination);

      processorNode.onaudioprocess = (e) => {
        if (!isCapturing) return;

        const inputBuffer = e.inputBuffer;
        const left = inputBuffer.getChannelData(0);
        const right = inputBuffer.numberOfChannels > 1 ? inputBuffer.getChannelData(1) : left;

        recordedChunksL.push(new Float32Array(left));
        recordedChunksR.push(new Float32Array(right));
        totalRecordedSamples += left.length;

        // Calculate Root-Mean-Square (RMS) for real-time VU meter
        let sum = 0;
        const step = 8;
        for (let i = 0; i < left.length; i += step) {
          sum += left[i] * left[i];
        }
        const rms = Math.sqrt(sum / (left.length / step));

        const sampleRate = audioCtx.sampleRate;
        const currentSec = totalRecordedSamples / sampleRate;
        const percent = captureTargetDuration > 0
          ? Math.min(100, Math.round((currentSec / captureTargetDuration) * 100))
          : 0;

        window.postMessage({
          type: 'SUNO_CAPTURE_PULSE',
          currentSec: currentSec,
          duration: captureTargetDuration,
          percent: percent,
          rms: rms
        }, '*');

        // Check if finished by sample count (with 0.25s margin for reverb tail)
        if (captureTargetDuration > 0 && currentSec >= captureTargetDuration + 0.25) {
          stopAndSaveCapture();
        }
      };
    }

    // Connect sourceNode to processorNode if not already connected
    if (!audioEl.__sunoConnectedToProcessor) {
      sourceNode.connect(processorNode);
      audioEl.__sunoConnectedToProcessor = true;
    }

    return true;
  }

  let activePollCancel = null;

  // Start Capture Process (With synchronization support for card clicks)
  async function startCapture(format, meta, silentMode, options = {}) {
    if (activePollCancel) {
      activePollCancel();
      activePollCancel = null;
    }
    isCapturing = false;
    recordedChunksL = [];
    recordedChunksR = [];
    totalRecordedSamples = 0;

    captureFormat = format === 'mp3' ? 'mp3' : 'wav';
    currentSongMeta = meta || { title: 'Suno Music', artist: 'june', clipId: '' };
    captureTargetDuration = meta.expectedDuration || 0;

    const waitForTrackChange = !!options.waitForTrackChange;
    const prevSrc = options.previousSrc || '';
    const targetClipId = meta.clipId || '';

    // Broadcast immediate HUD feedback
    window.postMessage({
      type: 'SUNO_CAPTURE_STARTED',
      format: captureFormat,
      title: currentSongMeta.title,
      artist: currentSongMeta.artist,
      duration: captureTargetDuration,
      silentMode: !!silentMode,
      isWaiting: waitForTrackChange
    }, '*');

    if (!waitForTrackChange) {
      // Immediate recording (player bar click or already playing)
      let audioEl = findAudioElement();
      if (!audioEl) {
        const startWait = Date.now();
        const waitInterval = setInterval(() => {
          audioEl = findAudioElement();
          if (audioEl || Date.now() - startWait > 1500) {
            clearInterval(waitInterval);
            if (audioEl) {
              beginActualRecording(audioEl, captureFormat, currentSongMeta, silentMode);
            } else {
              window.postMessage({
                type: 'SUNO_CAPTURE_ERROR',
                error: 'Suno 오디오 플레이어를 찾을 수 없습니다. 먼저 곡을 재생해 주세요.'
              }, '*');
            }
          }
        }, 100);
        return;
      }
      await beginActualRecording(audioEl, captureFormat, currentSongMeta, silentMode);
      return;
    }

    // Wait for Suno to switch to the clicked song and start playing
    let isCancelled = false;
    activePollCancel = () => { isCancelled = true; };

    const startPoll = Date.now();
    let directLoadAttempted = false;

    function pollCheck() {
      if (isCancelled) return;

      const audioEl = findAudioElement();
      if (audioEl) {
        const hasSrc = audioEl.src && audioEl.src.length > 0;
        const isTargetSrc = Boolean(targetClipId && hasSrc && audioEl.src.includes(targetClipId));
        const isNewSrc = Boolean(hasSrc && prevSrc && audioEl.src !== prevSrc);
        const isPlaying = !audioEl.paused && audioEl.currentTime >= 0;

        const durationMatches = Boolean(
          meta.expectedDuration > 0 &&
          audioEl.duration &&
          !isNaN(audioEl.duration) &&
          Math.abs(audioEl.duration - meta.expectedDuration) < 3.0
        );

        // Target track confirmed and playing!
        if ((isTargetSrc && isPlaying) || ((isNewSrc || durationMatches) && isPlaying && (!prevSrc || !audioEl.src.includes(prevSrc)))) {
          activePollCancel = null;
          beginActualRecording(audioEl, captureFormat, currentSongMeta, silentMode);
          return;
        }
      }

      if (Date.now() - startPoll < 8000) {
        setTimeout(pollCheck, 80);
      } else {
        // Strict safety timeout: NEVER replay previous song!
        activePollCancel = null;
        window.postMessage({
          type: 'SUNO_CAPTURE_ERROR',
          error: `'${currentSongMeta.title}' 곡의 재생 시작을 감지하지 못했습니다. 목록에서 직접 재생 버튼을 누른 후 캡처해 주세요.`
        }, '*');
      }
    }

    setTimeout(pollCheck, 100);
  }

  async function beginActualRecording(audioEl, format, meta, silentMode) {
    ensureAudioGraph(audioEl);

    // CRITICAL: Ensure audio context is active
    if (audioCtx && audioCtx.state === 'suspended') {
      try {
        await audioCtx.resume();
      } catch (e) {
        console.warn('[AudioCapture] AudioContext resume:', e);
      }
    }

    // Set speaker monitor mute state
    if (monitorGain) {
      monitorGain.gain.value = silentMode ? 0.0 : 1.0;
    }

    // Ensure audio element is actually playing
    try {
      if (audioEl.paused) {
        await audioEl.play();
      }
    } catch (err) {
      console.warn('[AudioCapture] Play attempt:', err);
    }

    // STRICT GUARD: If audio is still paused, wait for the 'playing' event!
    // NEVER record silence while paused!
    if (audioEl.paused) {
      console.log('[AudioCapture] Audio is buffering or waiting to play; waiting for playing event...');
      const onPlaying = () => {
        audioEl.removeEventListener('playing', onPlaying);
        beginActualRecording(audioEl, format, meta, silentMode);
      };
      audioEl.addEventListener('playing', onPlaying, { once: true });
      return;
    }

    // Audio is confirmed playing! Rewind player to 0:00 for clean beginning
    try {
      audioEl.currentTime = 0;
    } catch (err) {}

    captureTargetDuration = meta.expectedDuration || (audioEl.duration && !isNaN(audioEl.duration) ? audioEl.duration : 0);

    // Reset recording buffers
    recordedChunksL = [];
    recordedChunksR = [];
    totalRecordedSamples = 0;
    isCapturing = true;

    // Ended listener
    const onEndedHandler = () => {
      audioEl.removeEventListener('ended', onEndedHandler);
      if (isCapturing) {
        stopAndSaveCapture();
      }
    };
    audioEl.addEventListener('ended', onEndedHandler, { once: true });

    window.postMessage({
      type: 'SUNO_CAPTURE_STARTED',
      format: format,
      title: meta.title,
      artist: meta.artist,
      duration: captureTargetDuration,
      silentMode: !!silentMode,
      isWaiting: false
    }, '*');
  }

  // Stop & Encode & Download
  function stopAndSaveCapture() {
    if (!isCapturing && totalRecordedSamples === 0) return;
    isCapturing = false;

    window.postMessage({
      type: 'SUNO_CAPTURE_ENCODING',
      format: captureFormat
    }, '*');

    setTimeout(async () => {
      try {
        const sampleRate = audioCtx ? audioCtx.sampleRate : 44100;
        const totalLen = totalRecordedSamples;

        if (totalLen < sampleRate * 0.5) {
          throw new Error('녹음된 오디오 길이가 너무 짧습니다 (최소 0.5초 이상 필요).');
        }

        // Merge Float32Array chunks into single AudioBuffer
        const mergedBuffer = audioCtx.createBuffer(2, totalLen, sampleRate);
        const channel0 = mergedBuffer.getChannelData(0);
        const channel1 = mergedBuffer.getChannelData(1);

        let offset = 0;
        for (let i = 0; i < recordedChunksL.length; i++) {
          channel0.set(recordedChunksL[i], offset);
          channel1.set(recordedChunksR[i], offset);
          offset += recordedChunksL[i].length;
        }

        // Restore speaker volume
        if (monitorGain) {
          monitorGain.gain.value = 1.0;
        }

        let outBlob = null;
        let ext = 'wav';

        if (captureFormat === 'mp3') {
          outBlob = await encodeAudioBufferToMp3(mergedBuffer, 320);
          ext = 'mp3';
        } else {
          outBlob = encodeAudioBufferToWav(mergedBuffer);
          ext = 'wav';
        }

        const filename = `${currentSongMeta.title} - ${currentSongMeta.artist}.${ext}`;
        triggerDownload(outBlob, filename);

        window.postMessage({
          type: 'SUNO_CAPTURE_COMPLETED',
          format: ext,
          filename: filename,
          size: outBlob.size
        }, '*');

        // Clean memory
        recordedChunksL = [];
        recordedChunksR = [];
        totalRecordedSamples = 0;
      } catch (err) {
        console.error('[Capture Finish Error]', err);
        window.postMessage({
          type: 'SUNO_CAPTURE_ERROR',
          error: err.message || '인코딩 중 오류가 발생했습니다.'
        }, '*');
      }
    }, 50);
  }

  // Cancel Capture
  function cancelCapture() {
    if (activePollCancel) {
      activePollCancel();
      activePollCancel = null;
    }
    isCapturing = false;
    recordedChunksL = [];
    recordedChunksR = [];
    totalRecordedSamples = 0;

    if (monitorGain) {
      monitorGain.gain.value = 1.0;
    }

    window.postMessage({
      type: 'SUNO_CAPTURE_CANCELLED'
    }, '*');
  }

  // Set Monitor Mute State
  function setMonitorMute(isMuted) {
    if (monitorGain) {
      monitorGain.gain.value = isMuted ? 0.0 : 1.0;
    }
  }

  // Listen for commands from Content Script
  window.addEventListener('message', (event) => {
    if (!event.data || !event.data.type) return;

    if (event.data.type === 'SUNO_CMD_START_CAPTURE') {
      startCapture(event.data.format, event.data.meta, event.data.silentMode, {
        waitForTrackChange: !!event.data.waitForTrackChange,
        restartCurrent: !!event.data.restartCurrent,
        previousSrc: event.data.previousSrc || ''
      });
    } else if (event.data.type === 'SUNO_CMD_STOP_CAPTURE') {
      stopAndSaveCapture();
    } else if (event.data.type === 'SUNO_CMD_CANCEL_CAPTURE') {
      cancelCapture();
    } else if (event.data.type === 'SUNO_CMD_SET_MUTE') {
      setMonitorMute(event.data.isMuted);
    }
  });

  console.log('[Suno Audio Capture] Page bridge initialized with Web Audio API isolation.');
})();
